package business;

public class Formation {
	
	private String nom;
	

}
