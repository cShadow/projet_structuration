package business;

public class Auteur {
	
	private String nom;
	private String prenom;

}
