package business;

public class Utilisateur {
	
	private Role role;
	private String id;
	private String mdp;

}
