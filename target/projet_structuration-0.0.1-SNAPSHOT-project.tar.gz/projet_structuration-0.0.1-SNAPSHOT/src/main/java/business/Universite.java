package business;

import java.util.ArrayList;

public class Universite {

	private String nom;
	private ArrayList<Formation> formation;
	
}
