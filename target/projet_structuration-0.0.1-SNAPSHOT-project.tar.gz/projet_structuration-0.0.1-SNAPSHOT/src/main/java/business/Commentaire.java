package business;

import java.util.Date;

public class Commentaire {
	
	private Date date;
	private int note;
	private Auteur auteur;
	private String contenu;

}
