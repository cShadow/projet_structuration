package business;

public enum Role {
	etudiant,
	professeur,
	chercheur,
	administratif;

}
