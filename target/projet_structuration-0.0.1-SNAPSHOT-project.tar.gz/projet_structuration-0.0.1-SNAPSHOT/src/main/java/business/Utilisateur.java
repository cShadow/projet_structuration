package business;

public class Utilisateur {
	
	private String login;

}
